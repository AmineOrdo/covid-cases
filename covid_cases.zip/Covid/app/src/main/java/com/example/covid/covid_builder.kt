package com.example.covid
//constructeur qui sert à mettre les données json
class covid_builder(val date:String, val zone:String,
                    val category:String, val count:String, val location: String,val subzone:String
)